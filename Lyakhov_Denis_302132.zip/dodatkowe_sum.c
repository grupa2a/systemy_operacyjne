#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <pthread.h>
#include <errno.h>
#include <time.h>

int tab[2][10];

int thread_sum[2];

pthread_t threads[2];
pthread_mutex_t mutex;

void *findsum(void *arg);

int main(int argc, char *argv[]){
	
	int correct_sum = 0, found_sum, i;

	srand(time(0));

	for(i = 0; i < 2; i++){
		for(int j = 0; j < 10; j++){
			tab[i][j] = rand() % 100;
			correct_sum += tab[i][j];
			printf("%d\n",tab[i][j]);
		}
	}

	pthread_mutex_init(&mutex, NULL);

	for(i = 0; i < 2; i++)
		pthread_create(&threads[i], NULL, findsum, (void *) i);

	for(i = 0; i < 2; i++)
		pthread_join(threads[i], NULL);

	found_sum = thread_sum[0] + thread_sum[1];

	printf("Correct Sum = %d\n", correct_sum);
	printf("Thread Sum = %d\n", found_sum);

	pthread_mutex_destroy(&mutex);

	return 0;
}

void *findsum(void *arg){

	int sum = 0, i, j = (int *) arg;
	

	for(i = 0; i < 10; i++){
		sum += tab[j][i];
	}

	pthread_mutex_lock(&mutex);

	thread_sum[j] = sum;

	pthread_mutex_unlock(&mutex);

	pthread_exit((void *) 0);

	//return ((void *) 0);

}



































